from tkinter import *
okno = Tk()  
okno.geometry("400x250")


label1 = tk.Label(okno, text="Label 1")
label1.pack()

label2 = tk.Label(okno, text="Label 2")
label2.pack(after=label1)