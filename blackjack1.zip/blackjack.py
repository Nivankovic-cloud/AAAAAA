import random

# Původní balíček (nebo nějaký seznam karet)
puvodni_balicek = ['2♥', '3♥', '4♥', '5♥', '6♥', '7♥', '8♥', '9♥', '10♥', 'J♥', 'Q♥', 'K♥', 'A♥',
                   '2♦', '3♦', '4♦', '5♦', '6♦', '7♦', '8♦', '9♦', '10♦', 'J♦', 'Q♦', 'K♦', 'A♦',
                   '2♣', '3♣', '4♣', '5♣', '6♣', '7♣', '8♣', '9♣', '10♣', 'J♣', 'Q♣', 'K♣', 'A♣',
                   '2♠', '3♠', '4♠', '5♠', '6♠', '7♠', '8♠', '9♠', '10♠', 'J♠', 'Q♠', 'K♠', 'A♠']

# Zamíchání balíčku
def michani(obtinost):
    if obtinost == 1:
        balicek = puvodni_balicek.copy()
    elif obtinost == 2:
        balicek = puvodni_balicek * 3  # Trojnásobný balíček
    elif obtinost == 3:
        balicek = puvodni_balicek * 5  # Pěti-násobný balíček
    random.shuffle(balicek)
    return balicek

# Funkce pro kontrolu a zamíchání nového balíčku, pokud je karet málo
def kontrola(balicek, obtinost):
    if len(balicek) <= 12:  # Pokud zbývá 12 nebo méně karet
        print("Balíček je skoro prázdný, generuji nový a zamíchávám.")
        balicek = michani(obtinost)  # Vytvoření nového balíčku s danou obtížností
    return balicek

# Funkce pro rozdání karet
def rozdani_karet(kdo, pocet_karet, balicek, obtinost):
    karty_list = []
    skore = 0

    # Ujistíme se, že balíček je dostatečně velký
    balicek = kontrola(balicek, obtinost)

    # Rozdáme karty
    for _ in range(pocet_karet):
        karta = balicek.pop()
        karty_list.append(karta)
        skore += hodnota_karty(karta, skore)
    
    print(f"{kdo} dostal karty: {karty_list}")
    return karty_list, skore

# Funkce pro hodnocení karty (musí být definována)
def hodnota_karty(karta, skore):
    hodnoty = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 10, 'Q': 10, 'K': 10, 'A': 11}
    hodnota = karta[:-1]  # Odebíráme poslední znak (barvu karty)
    return hodnoty[hodnota]

# Příklad použití:
balicek = michani(1)  # Zamícháme balíček s obtížností 1

# Rozdáme 5 karet pro hráče
hrac_karty, hrac_skore = rozdani_karet("Hráč", 5, balicek, obtinost=1)

# Rozdáme 5 karet pro dealera
dealer_karty, dealer_skore = rozdani_karet("Dealer", 5, balicek, obtinost=2)

